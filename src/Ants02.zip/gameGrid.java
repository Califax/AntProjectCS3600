
public class gameGrid extends Tile {

	public gameGrid(int row, int col) {
		super(row, col);
		// TODO Auto-generated constructor stub
	}

	
}
