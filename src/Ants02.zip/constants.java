
public final class constants {
	
	public final static int WATER = 0;
	public final static int LAND = 1;
	public final static int FOOD = 2;
	public final static int MY_ANT = 3;
	public final static int DEAD = 4;
	public final static int ENEMY_ANT = 5;
	public final static int HILL = 6;
	public final static int ENEMY_HILL = 7;
	public final static int PLAYER_ID = 0;
	public final static int FOOD_VALUE = 3000;
	public final static int UNSEEN_VALUE = 1000;
	public final static int NORMAL_VALUE = 100; 
	public final static int INCREASE_VALUE = 1;
	public final static int ENEMY_ANT_VALUE = -300;
	public final static int ENEMY_ANT_DANGER = 1000;
	public final static int OUR_HILL_VALUE = 0;
	public final static int ENEMY_HILL_VALUE = 30000;
	public final static int FRIENDLY_ANT_VALUE = 0;
	public final static int AFTER_FOOD_VALUE = 100;
}
